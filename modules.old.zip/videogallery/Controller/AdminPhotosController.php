<?php

require_once "Core/Controller/Action.php";

class Videogallery_AdminPhotosController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
}
