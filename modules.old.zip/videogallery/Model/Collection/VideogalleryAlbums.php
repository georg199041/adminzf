<?php

class Videogallery_Model_Collection_VideogalleryAlbums extends Core_Model_Collection_Abstract
{
	
}