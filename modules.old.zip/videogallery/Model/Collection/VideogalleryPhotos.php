<?php

class Videogallery_Model_Collection_VideogalleryPhotos extends Core_Model_Collection_Abstract
{
	
}