<?php

class Videogallery_Model_Mapper_VideogalleryAlbums extends Core_Model_Mapper_Abstract
{
	
}