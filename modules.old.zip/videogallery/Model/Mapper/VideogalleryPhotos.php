<?php

class Videogallery_Model_Mapper_VideogalleryPhotos extends Core_Model_Mapper_Abstract
{
	
}