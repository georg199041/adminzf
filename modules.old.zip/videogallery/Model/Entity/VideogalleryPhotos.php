<?php

class Videogallery_Model_Entity_VideogalleryPhotos extends Core_Model_Entity_Abstract
{
	
}