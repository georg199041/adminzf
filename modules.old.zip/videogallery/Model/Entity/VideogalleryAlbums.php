<?php

class Videogallery_Model_Entity_VideogalleryAlbums extends Core_Model_Entity_Abstract
{
	
}