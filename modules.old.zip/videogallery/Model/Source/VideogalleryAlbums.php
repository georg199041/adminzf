<?php

class Videogallery_Model_Source_VideogalleryAlbums extends Core_Model_Source_DbTable
{
	
}