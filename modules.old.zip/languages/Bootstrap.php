<?php

require_once 'Core/Application/Module/Bootstrap.php';

class Languages_Bootstrap extends Core_Application_Module_Bootstrap
{    
    
}
