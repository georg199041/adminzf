<?php

class Recommendations_Model_Mapper_Posts extends Core_Model_Mapper_Abstract
{
	
}