<?php

class Recommendations_Model_Source_Posts extends Core_Model_Source_DbTable
{
	
}