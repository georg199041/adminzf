<?php

class Recommendations_Model_Entity_Posts extends Core_Model_Entity_Abstract
{
	
}