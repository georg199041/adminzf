<?php

class Recommendations_Model_Collection_Posts extends Core_Model_Collection_Abstract
{
	
}