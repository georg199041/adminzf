<?php

class Services_Model_Mapper_NewsletterTemplates extends Core_Model_Collection_Abstract
{
	
}