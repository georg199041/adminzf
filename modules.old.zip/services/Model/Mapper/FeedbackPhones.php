<?php

class Services_Model_Mapper_FeedbackPhones extends Core_Model_Collection_Abstract
{
	
}