<?php

class Services_Model_Mapper_NewsletterSubscribers extends Core_Model_Collection_Abstract
{
	
}