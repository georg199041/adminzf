<?php

class Services_Model_Collection_NewsletterSubscribers extends Core_Model_Collection_Abstract
{
	
}