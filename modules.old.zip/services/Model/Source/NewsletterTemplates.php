<?php

class Services_Model_Source_NewsletterTemplates extends Core_Model_Collection_Abstract
{
	
}