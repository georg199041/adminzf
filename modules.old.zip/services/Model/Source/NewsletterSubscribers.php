<?php

class Services_Model_Source_NewsletterSubscribers extends Core_Model_Collection_Abstract
{
	
}