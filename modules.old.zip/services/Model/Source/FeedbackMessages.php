<?php

class Services_Model_Source_FeedbackMessages extends Core_Model_Collection_Abstract
{
	
}