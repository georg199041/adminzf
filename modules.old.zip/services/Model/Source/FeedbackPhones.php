<?php

class Services_Model_Source_FeedbackPhones extends Core_Model_Collection_Abstract
{
	
}