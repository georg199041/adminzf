<?php

class Services_Model_Entity_NewsletterTemplates extends Core_Model_Collection_Abstract
{
	
}