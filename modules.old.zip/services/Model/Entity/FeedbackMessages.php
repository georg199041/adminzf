<?php

class Services_Model_Entity_FeedbackMessages extends Core_Model_Collection_Abstract
{
	
}