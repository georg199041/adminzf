<?php

class Services_Model_Entity_NewsletterSubscribers extends Core_Model_Collection_Abstract
{
	
}