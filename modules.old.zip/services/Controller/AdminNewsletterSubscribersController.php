<?php

require_once "Core/Controller/Action.php";

class Services_AdminNewsletterSubscriberController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
}
