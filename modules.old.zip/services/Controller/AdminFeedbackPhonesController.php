<?php

require_once "Core/Controller/Action.php";

class Services_AdminFeedbackPhonesController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
}
