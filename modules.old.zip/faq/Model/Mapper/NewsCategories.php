<?php

class News_Model_Mapper_NewsCategories extends Core_Model_Mapper_Abstract
{
	
}