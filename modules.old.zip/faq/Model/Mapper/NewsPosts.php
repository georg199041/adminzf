<?php

class News_Model_Mapper_NewsPosts extends Core_Model_Mapper_Abstract
{
	
}