<?php

class News_Model_Entity_NewsPosts extends Core_Model_Entity_Abstract
{
	
}