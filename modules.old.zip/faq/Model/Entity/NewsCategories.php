<?php

class News_Model_Entity_NewsCategories extends Core_Model_Entity_Abstract
{
	
}