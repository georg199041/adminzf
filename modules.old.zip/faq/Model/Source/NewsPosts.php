<?php

class News_Model_Source_NewsPosts extends Core_Model_Source_DbTable
{
	
}