<?php

class News_Model_Source_NewsCategories extends Core_Model_Source_DbTable
{
	
}