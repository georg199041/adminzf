<?php

class News_Model_Collection_NewsPosts extends Core_Model_Collection_Abstract
{
	
}