<?php

class News_Model_Collection_NewsCategories extends Core_Model_Collection_Abstract
{
	
}