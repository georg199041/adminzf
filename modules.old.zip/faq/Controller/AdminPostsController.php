<?php

require_once "Core/Controller/Action.php";

class News_AdminPostsController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
}
