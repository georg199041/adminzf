<?php

class Navigation_Model_Mapper_Pages extends Core_Model_Mapper_Abstract
{
	
}