<?php

class Navigation_Model_Collection_Pages extends Core_Model_Collection_Abstract
{
	
}