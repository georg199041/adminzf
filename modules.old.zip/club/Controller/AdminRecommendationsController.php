<?php

require_once "Core/Controller/Action.php";

class Club_AdminRecommendationsController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
}
