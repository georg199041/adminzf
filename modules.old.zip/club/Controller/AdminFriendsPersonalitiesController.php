<?php

require_once "Core/Controller/Action.php";

class Club_AdminFriendsPersonalitiesController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
}
