<?php

require_once "Core/Controller/Action.php";

class Club_AdminStaffController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
}
