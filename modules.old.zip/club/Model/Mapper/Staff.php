<?php

class Club_Model_Mapper_Staff extends Core_Model_Collection_Abstract
{
	
}