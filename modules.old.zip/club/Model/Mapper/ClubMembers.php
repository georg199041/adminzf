<?php

class Club_Model_Mapper_ClubMembers extends Core_Model_Collection_Abstract
{
	
}