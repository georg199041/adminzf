<?php

class Club_Model_Mapper_FriendsOrganizations extends Core_Model_Collection_Abstract
{
	
}