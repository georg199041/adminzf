<?php

class Club_Model_Mapper_Documents extends Core_Model_Collection_Abstract
{
	
}