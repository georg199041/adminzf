<?php

class Club_Model_Mapper_FriendsPersonalities extends Core_Model_Collection_Abstract
{
	
}