<?php

class Club_Model_Source_Recommendations extends Core_Model_Collection_Abstract
{
	
}