<?php

class Club_Model_Source_FriendsOrganizations extends Core_Model_Collection_Abstract
{
	
}