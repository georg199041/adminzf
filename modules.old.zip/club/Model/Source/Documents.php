<?php

class Club_Model_Source_Documents extends Core_Model_Collection_Abstract
{
	
}