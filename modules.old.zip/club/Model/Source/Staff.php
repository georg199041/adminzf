<?php

class Club_Model_Source_Staff extends Core_Model_Collection_Abstract
{
	
}