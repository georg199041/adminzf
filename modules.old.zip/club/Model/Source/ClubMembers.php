<?php

class Club_Model_Source_ClubMembers extends Core_Model_Collection_Abstract
{
	
}