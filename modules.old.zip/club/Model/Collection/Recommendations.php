<?php

class Club_Model_Collection_Recommendations extends Core_Model_Collection_Abstract
{
	
}