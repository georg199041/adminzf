<?php

class Club_Model_Collection_FriendsPersonalities extends Core_Model_Collection_Abstract
{
	
}