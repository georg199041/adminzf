<?php

class Club_Model_Collection_Documents extends Core_Model_Collection_Abstract
{
	
}