<?php

class Club_Model_Entity_FriendsPersonalities extends Core_Model_Collection_Abstract
{
	
}