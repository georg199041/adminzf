<?php

class Club_Model_Entity_Documents extends Core_Model_Collection_Abstract
{
	
}