<?php

class Club_Model_Entity_FriendsOrganizations extends Core_Model_Collection_Abstract
{
	
}