<?php

class Club_Model_Entity_Staff extends Core_Model_Collection_Abstract
{
	
}