<?php
return array(
	'layout' => array()
);