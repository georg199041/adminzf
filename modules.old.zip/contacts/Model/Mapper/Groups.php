<?php

class Contacts_Model_Mapper_Groups extends Core_Model_Mapper_Abstract
{
	
}