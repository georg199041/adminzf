<?php

class Contacts_Model_Mapper_Contacts extends Core_Model_Mapper_Abstract
{
	
}