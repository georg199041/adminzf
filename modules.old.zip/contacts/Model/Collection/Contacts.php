<?php

class Contacts_Model_Collection_Contacts extends Core_Model_Collection_Abstract
{
	
}