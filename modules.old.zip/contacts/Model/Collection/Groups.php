<?php

class Contacts_Model_Collection_Groups extends Core_Model_Collection_Abstract
{
	
}