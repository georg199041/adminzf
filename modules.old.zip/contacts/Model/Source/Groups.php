<?php

class Contacts_Model_Source_Groups extends Core_Model_Source_DbTable
{
	
}