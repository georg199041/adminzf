<?php

class Contacts_Model_Source_Contacts extends Core_Model_Source_DbTable
{
	
}