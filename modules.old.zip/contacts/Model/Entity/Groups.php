<?php

class Contacts_Model_Entity_Groups extends Core_Model_Entity_Abstract
{
	
}