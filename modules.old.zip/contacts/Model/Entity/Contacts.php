<?php

class Contacts_Model_Entity_Contacts extends Core_Model_Entity_Abstract
{
	
}