<?php

require_once 'Core/Application/Module/Bootstrap.php';

class Contacts_Bootstrap extends Core_Application_Module_Bootstrap
{    
    
}
