<?php

class Comments_IndexController extends Core_Controller_Action
{	
	public function init()
	{
		$this->view->headTitle('Comments');
	}
	
	public function indexAction(){}
	
	public function commentsAction(){}
}
