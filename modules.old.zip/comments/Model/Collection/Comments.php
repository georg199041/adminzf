<?php

class Comments_Model_Collection_Comments extends Core_Model_Collection_Abstract
{
	
}