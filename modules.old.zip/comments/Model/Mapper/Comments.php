<?php

class Comments_Model_Mapper_Comments extends Core_Model_Mapper_Abstract
{
	
}