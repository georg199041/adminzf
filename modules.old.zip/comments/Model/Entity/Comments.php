<?php

class Comments_Model_Entity_Comments extends Core_Model_Entity_Abstract
{
	
}