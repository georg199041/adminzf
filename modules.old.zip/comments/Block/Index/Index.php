<?php

class Comments_Block_Index_Index extends Core_Block_View
{
	
}