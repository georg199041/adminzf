<?php

class Params_Model_Collection_References extends Core_Model_Collection_Abstract
{
	
}