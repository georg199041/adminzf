<?php

class Params_Model_Collection_Names extends Core_Model_Collection_Abstract
{
	
}