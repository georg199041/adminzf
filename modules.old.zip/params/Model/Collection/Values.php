<?php

class Params_Model_Collection_Values extends Core_Model_Collection_Abstract
{
	
}