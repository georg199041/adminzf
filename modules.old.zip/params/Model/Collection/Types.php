<?php

class Params_Model_Collection_Types extends Core_Model_Collection_Abstract
{
	
}