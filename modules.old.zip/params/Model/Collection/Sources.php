<?php

class Params_Model_Collection_Sources extends Core_Model_Collection_Abstract
{
	
}