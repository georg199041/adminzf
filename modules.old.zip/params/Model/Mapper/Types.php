<?php

class Params_Model_Mapper_Types extends Core_Model_Mapper_Abstract
{
	
}