<?php

class Params_Model_Mapper_References extends Core_Model_Mapper_Abstract
{
	
}