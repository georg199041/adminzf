<?php

class Params_Model_Mapper_Sources extends Core_Model_Mapper_Abstract
{
	
}