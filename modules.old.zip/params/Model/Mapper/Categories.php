<?php

class Params_Model_Mapper_Categories extends Core_Model_Mapper_Abstract
{
	
}