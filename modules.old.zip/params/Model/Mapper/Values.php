<?php

class Params_Model_Mapper_Values extends Core_Model_Mapper_Abstract
{
	
}