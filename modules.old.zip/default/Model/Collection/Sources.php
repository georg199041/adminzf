<?php

class Default_Model_Collection_Sources extends Core_Model_Collection_Abstract
{
	
}