<?php

class Default_Model_Source_Sources extends Core_Model_Source_DbTable
{
	
}