<?php

class Default_Model_Entity_Sources extends Core_Model_Entity_Abstract
{
	
}