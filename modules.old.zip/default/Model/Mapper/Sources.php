<?php

class Default_Model_Mapper_Sources extends Core_Model_Mapper_Abstract
{
	
}