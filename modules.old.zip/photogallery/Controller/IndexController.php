<?php

class Photogallery_IndexController extends Core_Controller_Action
{	
	public function init()
	{
		$this->view->headTitle('Фотогалерея');
	}
	
	public function indexAction(){}
	
	public function albumAction(){}
}
