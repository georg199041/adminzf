<?php

class Photogallery_Model_Mapper_Images extends Core_Model_Mapper_Abstract
{
	
}