<?php

class Photogallery_Model_Entity_Albums extends Core_Model_Entity_Abstract
{
	
}