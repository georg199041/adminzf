<?php

class Photogallery_Model_Entity_Images extends Core_Model_Entity_Abstract
{
	
}