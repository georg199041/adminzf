<?php

class Photogallery_Model_Collection_Images extends Core_Model_Collection_Abstract
{
	
}