<?php

class Photogallery_Model_Collection_Albums extends Core_Model_Collection_Abstract
{
	
}