<?php

class Photogallery_Model_Source_Images extends Core_Model_Source_DbTable
{
	
}