<?php

class Contents_Model_Collection_Categories extends Core_Model_Collection_Abstract
{
	
}