<?php

class Contents_Model_Collection_Posts extends Core_Model_Collection_Abstract
{
	
}