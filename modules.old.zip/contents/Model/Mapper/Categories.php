<?php

class Contents_Model_Mapper_Categories extends Core_Model_Mapper_Abstract
{
	
}