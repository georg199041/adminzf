<?php

class Contents_Model_Source_Categories extends Core_Model_Source_DbTable
{
	
}