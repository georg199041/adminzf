<?php

class Contents_Model_Source_Posts extends Core_Model_Source_DbTable
{
	
}