<?php

require_once "Core/Controller/Action.php";

class Contents_IndexController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
    
    public function viewStaticAction()
    {
    	
    }
    
    public function recommendationsAction()
    {
    	
    }
    
    public function galleryAction()
    {
    	
    }

	public function galleryAlbumAction(){}

	public function personalAction(){}
}
