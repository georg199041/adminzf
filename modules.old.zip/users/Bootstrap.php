<?php

require_once 'Core/Application/Module/Bootstrap.php';

class Users_Bootstrap extends Core_Application_Module_Bootstrap
{    
    
}
