<?php

class Users_Model_Mapper_UsersRoles extends Core_Model_Mapper_Abstract
{
	
}