<?php

class Users_Model_Mapper_Users extends Core_Model_Mapper_Abstract
{
	
}