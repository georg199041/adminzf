<?php

class Users_Model_Mapper_Roles extends Core_Model_Mapper_Abstract
{
	
}