<?php

class Users_Model_Source_Users extends Core_Model_Source_DbTable
{
	
}