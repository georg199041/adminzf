<?php

class Users_Model_Source_Roles extends Core_Model_Source_DbTable
{
	
}