<?php

class Users_Model_Source_UsersRoles extends Core_Model_Source_DbTable
{
	
}