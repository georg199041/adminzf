<?php

class Users_Model_Entity_Users extends Core_Model_Entity_Abstract
{
	
}