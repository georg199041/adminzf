<?php

class Users_Model_Entity_UsersRoles extends Core_Model_Entity_Abstract
{
	
}