<?php

class Users_Model_Entity_Roles extends Core_Model_Entity_Abstract
{
	
}