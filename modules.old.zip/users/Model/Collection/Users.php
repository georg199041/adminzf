<?php

class Users_Model_Collection_Users extends Core_Model_Collection_Abstract
{
	
}