<?php

class Users_Model_Collection_UsersRoles extends Core_Model_Collection_Abstract
{
	
}