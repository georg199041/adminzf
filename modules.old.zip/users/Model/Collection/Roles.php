<?php

class Users_Model_Collection_Roles extends Core_Model_Collection_Abstract
{
	
}