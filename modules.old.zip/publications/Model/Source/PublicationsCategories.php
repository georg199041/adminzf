<?php

class Publications_Model_Source_PublicationsCategories extends Core_Model_Source_DbTable
{
	
}