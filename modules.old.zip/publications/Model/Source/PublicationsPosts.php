<?php

class Publications_Model_Source_PublicationsPosts extends Core_Model_Source_DbTable
{
	
}