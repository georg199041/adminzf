<?php

class Publications_Model_Entity_PublicationsPosts extends Core_Model_Entity_Abstract
{
	
}