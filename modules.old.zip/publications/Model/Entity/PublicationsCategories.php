<?php

class Publications_Model_Entity_PublicationsCategories extends Core_Model_Entity_Abstract
{
	
}