<?php

class Publications_Model_Mapper_PublicationsPosts extends Core_Model_Mapper_Abstract
{
	
}