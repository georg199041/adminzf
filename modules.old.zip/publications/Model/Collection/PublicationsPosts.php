<?php

class Publications_Model_Collection_PublicationsPosts extends Core_Model_Collection_Abstract
{
	
}