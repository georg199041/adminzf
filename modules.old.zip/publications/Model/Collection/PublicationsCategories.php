<?php

class Publications_Model_Collection_PublicationsCategories extends Core_Model_Collection_Abstract
{
	
}