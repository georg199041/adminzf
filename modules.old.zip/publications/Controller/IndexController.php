<?php

require_once "Core/Controller/Action.php";

class Publications_IndexController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
}
