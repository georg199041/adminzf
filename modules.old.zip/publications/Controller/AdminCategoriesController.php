<?php

require_once "Core/Controller/Action.php";

class Publications_AdminAlbumsController extends Core_Controller_Action
{	
	public function init()
	{
		
	}
	
	public function indexAction()
    {
		
    }
}
