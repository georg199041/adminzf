<?php

require_once 'Core/Application/Module/Bootstrap.php';

class News_Bootstrap extends Core_Application_Module_Bootstrap
{    
    
}
