-- phpMyAdmin SQL Dump
-- version 3.4.11.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Дек 12 2012 г., 06:58
-- Версия сервера: 5.5.28
-- Версия PHP: 5.2.17

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `shmaliym_roy`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments_comments`
--

DROP TABLE IF EXISTS `comments_comments`;
CREATE TABLE IF NOT EXISTS `comments_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table` varchar(255) DEFAULT NULL,
  `table_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `user_agent` text NOT NULL,
  `comment` text,
  `status` enum('MODERATED','NOTVIEWED','REJECTED') NOT NULL DEFAULT 'NOTVIEWED',
  `created_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `comments_comments`
--

INSERT INTO `comments_comments` (`id`, `table`, `table_id`, `name`, `email`, `ip`, `user_agent`, `comment`, `status`, `created_ts`) VALUES
(9, 'photogallery_albums', 7, 'Yara', 'elena@sunny.net.ua', '5.1.7.135', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)', 'Удивительно разнообразное место: и пещеры с останками динозавров, и водопады с кристально чистой водой, и горы, и поля с лошадьми и цветами! Стоит съездить хотя бы раз - и Вам захочется возвращаться туда снова и снова.', 'MODERATED', 1354623719),
(10, 'photogallery_albums', 7, 'vertus', 'almarein@mail.ru', '46.164.131.138', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:16.0) Gecko/20100101 Firefox/16.0', 'Круто!', 'MODERATED', 1354882501);

-- --------------------------------------------------------

--
-- Структура таблицы `contacts_contacts`
--

DROP TABLE IF EXISTS `contacts_contacts`;
CREATE TABLE IF NOT EXISTS `contacts_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contacts_groups_id` int(11) DEFAULT NULL,
  `type` enum('ADDRESS','MAINPHONE','PHONE','EMAIL','SKYPE','LATLNG','QRCODE','IMAGE','LINK') NOT NULL DEFAULT 'ADDRESS',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `contacts_groups_id` (`contacts_groups_id`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `contacts_contacts`
--

INSERT INTO `contacts_contacts` (`id`, `contacts_groups_id`, `type`, `title`, `alias`, `description`, `image`, `enabled`) VALUES
(1, 1, 'ADDRESS', 'Адрес базы в крыму', 'crimea_address', '', '', 'YES'),
(2, 1, 'MAINPHONE', 'Основной телефон', 'crimea_main_phone', '+38 (050) 545-33-69', NULL, 'YES'),
(3, 1, 'PHONE', 'Телефон', 'crimea_phone', '+38 (096) 239-35-79', '', 'YES'),
(4, 1, 'EMAIL', 'Эл. почта', 'crimea_email', 'info@roi-crimea.org', '', 'YES'),
(5, 1, 'SKYPE', 'skype', 'crimea_skype', 'Che', NULL, 'YES'),
(6, 1, 'LATLNG', 'google', 'crimea_google', '44.858614,34.330688', '', 'YES'),
(7, 1, 'QRCODE', 'QR код', 'crimea_qr', '', '/uploads/crimea-qr-code.gif', 'YES'),
(8, 2, 'ADDRESS', 'Адрес в Москве:', 'moscow_address', 'г.Москва, ул.Дубнинская д.14, к.2', NULL, 'YES'),
(9, 2, 'MAINPHONE', 'Телефон в москве', 'moscow_main_phone', '+7 (963) 610-00-95 (резервный номер)', '', 'YES'),
(10, 2, 'LATLNG', 'google', 'moscow_google', '48.382803,31.17461', NULL, 'YES'),
(11, 2, 'QRCODE', 'QR код', 'moscow_qr', '', '/uploads/moscow-qr-code.gif', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `contacts_feedback`
--

DROP TABLE IF EXISTS `contacts_feedback`;
CREATE TABLE IF NOT EXISTS `contacts_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` text,
  `answer_from` varchar(255) DEFAULT NULL,
  `answer_name` varchar(255) DEFAULT NULL,
  `answer_subject` varchar(255) DEFAULT NULL,
  `answer_message` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `contacts_feedback`
--

INSERT INTO `contacts_feedback` (`id`, `name`, `email`, `message`, `answer_from`, `answer_name`, `answer_subject`, `answer_message`) VALUES
(1, 'egerg', 'pavlenko.obs@gmail.com', 'dgrtrth', 'pavlenko.obs@gmail.com', NULL, '123', 'rehtdtrhjrjtutuik'),
(2, 'vertus', 'vertus@sunny.net.ua', 'Test.', NULL, NULL, NULL, NULL),
(3, 'v', 'vertus@sunny.net.ua', 'vertus', NULL, NULL, NULL, NULL),
(4, 'sdf', 'sdf@sdf.ru', 'sdf', NULL, NULL, NULL, NULL),
(5, 'фывафывафыва', 'admin@admin.com', 'fasdfasdfasdfasdf', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `contacts_groups`
--

DROP TABLE IF EXISTS `contacts_groups`;
CREATE TABLE IF NOT EXISTS `contacts_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `contacts_groups`
--

INSERT INTO `contacts_groups` (`id`, `title`, `alias`, `description`, `enabled`) VALUES
(1, 'База в Крыму', 'crimea_base', '<p>Живописное меcто Крыма расположено за селом Перевальное по пути из столицы Крыма &mdash; Симферополя &mdash; на Южный берег Крыма, трасса &laquo;Симферополь-Ялта&raquo;.</p>\r\n<p>От авто- или железнодорожного вокзала доехать маршруткой &laquo;Симферополь-Перевальное&raquo; до остановки &laquo;Красная пещера&raquo; или троллейбусами 51, 52, 53 до остановки &laquo;Стадион&raquo;.</p>\r\n<p><strong>Или позвоните нам, и мы Вас встретим.<br /><br /></strong>97578<br />АР Крым,<br />Симферопольский район, <br />с. Перевальное, <br />ул.Стадионная 11.<strong><br /></strong></p>', 'YES'),
(2, 'Офис в Москве', 'moscow_office', NULL, 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_categories`
--

DROP TABLE IF EXISTS `contents_categories`;
CREATE TABLE IF NOT EXISTS `contents_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contents_categories_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `alias` (`alias`),
  KEY `contents_categories_id` (`contents_categories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `contents_categories`
--

INSERT INTO `contents_categories` (`id`, `contents_categories_id`, `title`, `alias`, `description`, `enabled`) VALUES
(1, NULL, 'Тестовая категория', 'tteesstt', 'des', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_posts`
--

DROP TABLE IF EXISTS `contents_posts`;
CREATE TABLE IF NOT EXISTS `contents_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contents_categories_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `introtext` text,
  `fulltext` text,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  `meta_keywords` text,
  `meta_description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `contents_categories_id` (`contents_categories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `contents_posts`
--

INSERT INTO `contents_posts` (`id`, `contents_categories_id`, `title`, `alias`, `introtext`, `fulltext`, `enabled`, `order`, `meta_keywords`, `meta_description`) VALUES
(1, NULL, 'О клубе', 'about_club', '', '<p>Спортивно-оздоровительный клуб &laquo;Рой&raquo; предлагает комплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма, включающее в себя:</p>\r\n<ol>\r\n<li>Профилактику и реабилитацию зависимостей любых видов (алко- и наркозависимостей, консультации психолога, лечение наркомании);</li>\r\n<li>Курс восстановления после перенесенных травм суставов и сухожилий, при ослаблении организма, связанного с малоподвижным образом жизни и длительной работой на персональном компьютере;</li>\r\n<li>Общее оздоровление с применением Индотебетской и Старославянской практик с использованием:</li>\r\n<ul>\r\n<li>Лекарственных растений Крымских гор;</li>\r\n<li>АПИ терапии (профилактика с применением пчелоукалывания);</li>\r\n<li>Купание в живой воде горного водопада;</li>\r\n<li>Массажные процедуры с применением масел природной среды и одновременной диагностикой организма;</li>\r\n<li>Посещение бани в условиях уникальной природы;</li>\r\n<li>Спортивные мероприятия (волейбол, мини-футбол, работа на спортивных снарядах);</li>\r\n<li>Ознакомление с навыками рукопашного боя и отдельными приемами Восточных единоборств под руководством наставника.</li>\r\n<li>Возможны конные экскурсии, поездки на морское побережье Крыма.</li>\r\n</ul>\r\n</ol><br />Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.<br /><br />Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.<br /><br />Уделите несколько минут Вашего времени на изучение краткой информации о нашей методике лечения наркозависимости и реабилитационном центре в Крыму, посетите нашу фотогалерею, а Ваши последние сомнения окончательно развеют опытные специалисты, проконсультироваться с которыми можно по телефонам в Москве +7 495 668-12-73 и Украине +38 050 545-33-69.<br />\r\n<h3>Базовый лагерь клуба</h3>\r\n<h4>Реабилитационный центр и жизнь среди природы</h4>\r\nАвторская программа реабилитации наркозависимых включает в себя проживание в деревянных домиках в природных условиях, а также использование природных оздоровительных процедур.<br /><br />На территории лагеря оборудована баня, речная купель, спортивная площадка. Проживание и столовая расположены в комфортабельных домиках &laquo;финского типа&raquo;. Жилые помещения центра имеют все условия для круглогодичной реабилитации наркозависимых и лечения наркомании. Спортивный зал с мягким покрытием предназначен для круглогодичного использования и расположен в утепленных палатках армейского типа. В зимний период жилые помещения обогреваются русскими печами.<br />\r\n<h3>Спортивно-оздоровительный клуб</h3>\r\n<h4>Реабилитация - Оздоровление - Исцеление</h4>\r\nЭто не просто девиз&nbsp;&mdash; это практика восстановления здоровья и жизненной энергии через общение с Природой и следования её законам.<br /><br />Уникальная программа реабилитации зависимых от психоактивных веществ защищена Свидетельством регистрации авторского права №23593 Министерства образования и науки Украины, Государственным департаментом интеллектуальной собственности.', 'YES', NULL, '', ''),
(3, NULL, 'Миссия и цели', 'mission-and-goals', '', '<h4>Миссия</h4>\r\n<p>&laquo;Рой&raquo; является спортивно-оздоровительным клубом, деятельность которого направлена на психофизиологическую коррекцию, а также реабилитацию наркозависимых и подготовку спортсменов, проведение таких общеоздоровительных программ: семинары, тренинги и сборы, основой которых является близость к природе и использование мощного энергетического потенциала природы.</p>\r\n<h4>Цели</h4>\r\n<p>В течение 2013 года, используя программу клуба, мы готовы принять на реабилитацию, ресоциализацию и общее оздоровление следующие категории населения:</p>\r\n<ul>\r\n<li>зависимые: более 200 человек;</li>\r\n<li>нуждающиеся в оздоровлении: более 300 человек;</li>\r\n<li>подготовка спортсменов: более 200 человек.</li>\r\n</ul>', 'YES', NULL, '', ''),
(4, NULL, 'База клуба', 'club_base', '', '<p>База СК &laquo;РОЙ&raquo;, расположена в уникальном природном заповеднике&nbsp;&mdash; <a href="http://maps.google.com.ua/maps?q=44.858867,34.331294&amp;hl=ru&amp;sll=44.858911,34.331245&amp;sspn=0.066073,0.169086&amp;t=h&amp;z=13" target="_blank">урочище &laquo;Красная пещера&raquo;</a>, в условиях полной социальной изоляции, на берегу горной реки, поблизости от водопада &laquo;Су-Учхан&raquo;. Высота над уровнем моря 350 м.</p>\r\n<p style="text-align: center;"><img src="/uploads/6.jpg" alt="" width="550" height="413" /></p>\r\n<p>Участники программы проживают в деревянных домиках вместе с воспитателями-инструкторами.</p>\r\n<p style="text-align: center;"><img src="/uploads/12.jpg" alt="" width="550" height="405" /></p>\r\n<p>На территории базы расположен пищеблок, туалеты-септики, волейбольная и баскетбольная площадки, спортивный уголок для силовых упражнений, инвентарь для настольного тенниса.</p>\r\n<p style="text-align: center;"><img src="/uploads/5.jpg" alt="" width="550" height="413" /></p>\r\n<p>На берегу ручья расположена русская баня на дровах с купелью. Естественный природный быт лагеря подчеркивают фруктовый сад, виноградник, огород, собственная пасека и минимальное животноводческое хозяйство (козы и куры).</p>\r\n<p style="text-align: center;"><img src="/uploads/13.jpg" alt="" width="550" height="413" /></p>', 'YES', NULL, '', ''),
(5, NULL, 'Методика', 'methodology', '', '<p>Программа предназначена для людей, страдающих физиологической и психологической зависимостью от психоактивных веществ (в т.ч. алкоголя) любой степени тяжести, а также имеющие другие зависимости (компьютер, азартные игры, секс и пр.). В программе могут принимать участие мужчины и женщины от 16 до 50 лет, жители Украины и граждане других стран.</p>\r\n<h3>Составляющие элементы программы</h3>\r\n<h4>Элемент №1</h4>\r\n<p>Купирование абстинентного синдрома, проведение психофизической реабилитации пациента в условиях социальной изоляции с использованием природных факторов, отличающейся тем, что снятие наркозависимости у пациента, проводят на трех уровнях:</p>\r\n<ul>\r\n<li>физиологическом;</li>\r\n<li>эмоционально-психологическом;</li>\r\n<li>ментальном;</li>\r\n</ul>\r\n<p>с использованием внутреннего потенциала самовосстановления и развитием у пациента новой потребности&nbsp;&mdash; стремления к творчеству.</p>\r\n<h4>Элемент №2</h4>\r\n<p>При снятии физиологической наркозависимости, проводят детоксикацию организма пациента без использования медикаментозных средств и исключают употребление пациентом наркотических средств на весь период реабилитации, кроме того, проводят очистительное питание.</p>\r\n<h4>Элемент №3</h4>\r\n<p>При снятии эмоционально-психологической наркозависимости, формируют привычку получения ярких позитивных эмоций от действий, не связанных с употреблением наркотиков, а также формируют привычку творческого, активного и эффективного решения психоэмоциональных проблем, исключая при этом жесткий гипноз и кодирование пациента.</p>\r\n<h4>Элемент №4</h4>\r\n<p>Снятие ментальной наркозависимости выполняют путем изоляции пациента от привычной социальной среды и формирования нового мировоззрения, включающего установки на смену привычной социальной среды и противодействие ее соблазнам, исключая при этом &laquo;промывание мозгов&raquo; и навязывание религиозно-идеологических стереотипов.</p>', 'YES', NULL, '', ''),
(6, NULL, 'Сущность программы', 'program', '', '<h3>Этап № 1. Работа с телом</h3>\r\n<h4>Акцент на снятие физической зависимости.</h4>\r\n<p>На этом этапе проводится первичная детоксикация организма, а в тяжелых случаях &ndash; снятие острого абстинентного синдрома. При очистке организма используются настои из экологически чистых крымских трав, натуральные масла, настойки на сыворотке, горный мед и другие продукты пчеловодства, морская соль.</p>\r\n<p>Основные оздоровительные процедуры&nbsp;&mdash; терморегуляция (купание в водопаде и горной реке, русская баня), массаж, лечебное дыхание ( в том числе с водяным затвором), прием травяных настоев седативного действия. Сон на пчелиной семье в специально оборудованном помещении.</p>\r\n<h3>Этап № 2. Восстановление нормального психоэмоционального состояния</h3>\r\n<h4>Акцент на снятие психологической&nbsp; зависимости.</h4>\r\n<p>На этом этапе основной&nbsp; задачей является выработка позитивного эмоционально-психологического&nbsp; настроя. Единение с природой, прогулки по горному лесу, купание в водопаде, встреча восхода и захода солнца в горах, совместный труд, беседы и песни у костра вызывают душевную радость и включают механизм выработки организмом естественных эндорфинов.</p>\r\n<p>Продолжается работа над телом&nbsp;&mdash; очистка печени и крови, основном с использованием рефлексотерапии&nbsp;&mdash; апипунктура (постановка пчел на биоактивные точки в соответствии с принципами китайской медицины, массаж с использованием натуральных масел.</p>\r\n<h3>Этап № 3. Восстановление базовых ценностей</h3>\r\n<h4>Акцент на снятие ментальной зависимости.</h4>\r\n<p>Основная задача этого этапа&nbsp;&mdash; пробуждение веры в самого себя, в свое Божественное начало, осознание своего предназначения.</p>\r\n<p>Групповые тренинги и индивидуальные занятия с психологом приводят к осознанию человеком своей социальной реализации, жизненных целей и планов на будущее.</p>\r\n<p>Продолжается работа с телом&nbsp;&mdash; комплекс упражнений реабилитационно&nbsp;&mdash; тренировочной методики Голтиса (<a href="http://goltis.info/" target="_blank">www.goltis.info</a>), комплексы преобразования связок, суставов и сухожилий.</p>\r\n<h3>Этап № 4. Закрепление</h3>\r\n<h4>Закрепление полученных изменений.</h4>\r\n<p>Идет работа над собой с учетом индивидуальных проблемных и недоработанных аспектов, а так же с учетом планов на будущее, выстроенных бывшим зависимым. Консультации психолога с родными бывшего зависимого, по телефону или на очной встрече, с целью принятия вновь возрожденного человека в семью, не вторгаясь в его личную жизнь.</p>', 'YES', NULL, '', ''),
(7, NULL, 'Результаты прохождения программы', 'findings', '', '<p><strong>На первом этапе</strong> проходит детоксикация организма без использования медикаментов, исключительно на основе использования природных компонентов, снимаются депрессивные состояния, нормализуется аппетит и сон.</p>\r\n<p><strong>На 2-м этапе</strong> вырабатывается позитивный эмоционально&nbsp;&mdash; психологический настой, включается выработка организмом естественных эндорфинов. Опытные наставники&nbsp;&mdash; психологи помогают решать личные проблемы, мешавшие нормальной жизни человека в социуме.</p>\r\n<p><strong>На 3-м этапе</strong> делается акцент на снятии ментальной зависимости, человек обретает новую опору в жизни на основании вновь выстроенных ценностей.</p>\r\n<p><strong>На 4-м этапе</strong> формируются планы на будущее, четко обозначается мотивационная программа для возвращения пациента в социум.</p>', 'YES', NULL, NULL, NULL),
(8, NULL, 'Расписание дня в лагере', 'schedule', '', '<table style="width: 600px;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>6:30</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>подъем.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>6:30&nbsp; &nbsp;7:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>гигиенические процедуры.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>7:00 &nbsp;&nbsp;8:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>гимнастика для суставов и пластика тела.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>8:00&nbsp; &nbsp;9:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>прогулка по горному лесу, купание в водопаде, посещение целебного&nbsp; горного источника.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>9:00&nbsp; &nbsp;9:30</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>завтрак.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>9:30 &nbsp;&nbsp;10:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>свободное время, отдых.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>10:00 13:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>работы по жизнеобеспечению и благоустройству лагеря, забота о животных, огород и пр.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>13:00 14:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>свободное время, отдых.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>14:00 15:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>обед.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>15:00 17:30</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>свободное время, отдых (в распоряжении лагеря есть ТВ и библиотека).</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>17:30 19:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>тренировка по методике Голтиса (физические упражнения без использования утяжелений), индо-тибетские практики укрепления суставов, связок и сухожилий.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>19:00 20:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>русская баня.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>20:00 20:30</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>ужин.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>20:30 22:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>свободное время, отдых.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong>22:00</strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p>отбой.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>Такой распорядок продолжается с понедельника по субботу.</p>\r\n<p>В воскресение&nbsp;&mdash; отдых на берегу моря или поход в горы с проводником.</p>', 'YES', NULL, NULL, NULL),
(9, NULL, 'Документы', 'documentation', '', '<p>Способ реабилитации наркозависимости, используемый в программе СК &laquo;РОЙ&raquo; защищен патентом № 41030 от 27.04.2009 г., лицензия МОЗ Украины&nbsp; АВ № 565544, регистрация 02.09.2010 г.<br /><br /></p>', 'NO', NULL, NULL, NULL),
(10, NULL, 'Рекомендации', 'recommendations', '', '<h3 style="text-align: center;">Республиканский наркологический диспансер АР Крым</h3>\r\n<p><br />Спортивно-оздоровительный клуб "РОЙ" - зрелое реабилитационное учреждение, предоставляющее наркозависимым помощь на этапах реадаптаци, реабилитации и дальнейшей ресоциализации.</p>\r\n<p>В клубе разработана оригинальная 4-х шаговая методика реабилитаци, основанная на физиотерапевтических природных процедурах, психологическом воздействии средой и коллективной трудотерапией.</p>\r\n<p>В реабилитационном процессе используются бывшие пациенты - инструктора. Пациенты реабилитационной программы живут ощущением единой команды, проживают в общих палатках с инструкторами. Медицинские препараты в программе не применяются, за исключением сборов трав и продуктов пчеловодства.</p>\r\n<p>Клуб "РОЙ" обеспечил реабилитационную работу европейского уровня, что отличает его от многих реабилитационных наркологических учреждений. Для Украины реабилитационная программа клуба "РОЙ" - один из ростков наркологии будущего.<br /><br /><br /></p>\r\n<h3 style="text-align: center;">Кафедра психиатрии, наркологии и психотерапии Крымского медицинского университета им. С.И.Георгиевского</h3>\r\n<p><br />Предлагаемая спортивно-оздоровительным клубом "РОЙ" программа работы с лицами, зависимыми от психоактивных веществ, а также зависимых от других объектов (компьютера, азартных игр, секса и т.д.) включает в себя комплекс реабилитации и ресоциализации, которые хорошо согласуются с требованиями современной психотерапевтической, клинической практики. Программа является эффективной при снятии основных наркологических синдромов, реабилитации и последующей социальной адаптации.</p>\r\n<p>В частности, реабилитационная программа включает в себя широкий арсенал приемов биологической терапии, физиотерапии, индивидуальной и групповой психотерапии. Фармакотерапевтическое вмешательство не применяется. Лишь в тяжелых случаях при необходимости проводится детоксикационная (дезинтоксикационная), заместительная, а также ургентная (неотложная) терапия.</p>\r\n<p>Отличительной чертой программы клуба "РОЙ", созданной ее руководителем Линевым Павлом Владимировичем, является полное погружение в необычную для большинства зависимых среду. В ней "природный образ жизни" и восточные практики оздоровления и физического развития (адаптированные для нашего менталитета) создают благоприятный фон для проведения процедур групповой психотерапии и физиотерапевтического воздействия.</p>\r\n<p>Данную программу модно рекомендовать для реабилитации пациентов с легкой и средней степенью зависимости, а в некоторых случаях - и при тяжелых формах зависимости, в том числе прошедшим курс стационарного лечения в специализированных наркологических учреждениях. Программа также рекомендуется для оздоровления, реабилитации лиц с различными невротическими расстройствами и психологическими проблемами в подростковом возрасте.</p>', 'NO', NULL, NULL, NULL),
(11, NULL, 'История', 'history', '', '<p>Наверняка вы сейчас ожидаете от меня невероятной истории о том, каким волшебным образом я придумал программу реабилитации и пропагандирую ее всем и вся. Но, к счастью или к печали, процесс создания программы обстоял несколько иначе&nbsp;&mdash; более долго, более дорого и, конечно же, нелегко.</p>\r\n<p>Когда ко мне стали поступать просьбы помощи от родителей наркозависимых, я был тренером&nbsp; и имел психологическое и педагогическое образование. Но я осознавал, что для более эффективной помощи мне необходим некий комплекс информации и знаний, которые сочетались бы между собой, позволяя мне осуществлять профессиональное лечение наркозависимых.</p>\r\n<p>С тех пор я приступил к сбору различной информации, касающейся наркологии, психологии человека, древних восточных и славянских знаний. Я объехал Китай и Россию в поисках целебных практик и учений разных народностей. Мне приходилось месяцами и того больше&nbsp;&mdash; годами отрабатывать те или иные техники, совершенствуя свою реабилитационную программу. Я старался создать настолько идеальную программу, которая способна без медикаментозного вмешательства вылечить самые сложные степени зависимостей, включая приемы биологической терапии, физиотерапии, индивидуальной и групповой психотерапии. И только лишь в единичных и крайне тяжелых случаях при необходимости проводится детоксикационная терапия.</p>\r\n<p>Мне удалось собрать воедино целый ряд процедур, которые способствуют реабилитации: нахождение в единстве с природой, соблюдение прав человека и пациента, круглосуточная поддержка как наставниками-воспитателями, так и единомышленниками, братская поддержка, соблюдение установленного для всех режима дня, работы по благоустройству территории реабилитационного лагеря, высадка деревьев и овощей, физические тренировки с мастерами спорта, подвижные командные игры, купание в живописном водопаде, и многое-многое другое.</p>\r\n<p>На сегодняшний день более 1000 человек прошли реабилитационный курс по данной программе, но снова и снова меня вдохновляют слова благодарения от родителей, которым удается вернуть своих детей в естественное жизненное русло.</p>\r\n<p>Я потратил немало средств и усилий для создания клубной базы в Крыму, где, собственно, применяю программу на благо пациентов и общества в целом. Каждый участник реабилитации, пребывая в нашем лагере, внес частичку себя, своей воли, своего желания жить, а не существовать, и я прилагаю максимум усилий для совершенствования программы и развития Клуба &laquo;Рой&raquo;.</p>', 'YES', NULL, NULL, NULL),
(12, NULL, 'Слово руководителя', 'according-to-head-of', '', '<p>В настоящее время наш мир переполнен бедами и болезнями, а наши дети с самого юного возраста неосознанно ходят по лезвию бритвы&nbsp;&mdash; на каждом повороте их может ждать опаснейший враг&nbsp;&mdash; наркотик. И поскольку Вы сейчас читаете этот текст, то скорее всего, и Ваших близких коснулась проблема зависимости, но даже если это не так, просто вспомните свое ближнее и дальнее окружение. Насколько высока вероятность, что в Вашем кругу знакомых есть люди, зависимые от того или иного психоактивного вещества.&nbsp;</p>\r\n<p>Я не хочу нагнетать страх. Моя задача заключается в том, чтобы донести в широкую общественность достижения человечества в области лечения наркомании и другого рода зависимостей.</p>\r\n<p>Основание столь громких слов&nbsp;&mdash; это моя тренерская и педагогическая деятельность. Будучи преподавателем и тренером на протяжении более 20 лет, ко мне начали обращаться родители с просьбами о помощи их детям, зависимым от наркотических веществ.</p>\r\n<p>Понимая всю ответственность за судьбы и здоровье человека, попавшего в беду, и сложность решения его проблемы, возникла необходимость поиска максимально эффективной информации и знаний для формирования целостной авторской программы. Начиная с 2000 года и по сегодняшний день, через эту программу прошли более тысячи человек из самых разных регионов земного шара, включая Западную Европу и Америку. Особенно я хочу отметить моих бывших пациентов &ndash; врачей-психотерапевтов из США.</p>\r\n<p>Фундаментальным блоком программы является апитерапия, положившая свое начало в далеком 1894 году. Апитерапия представляет собой лечение целебными продуктами пчел. Естественные генетические программы, что заложены в этих продуктах, позволяют восстанавливать как органы, так и целые системы организма.</p>\r\n<p>Пройдя курс лечения на клубной базе пациент избавляется от проблематики без химического вмешательства и получает побочный эффект в виде общего восстановления организма, вплоть до регенерации функций внутренних органов.</p>\r\n<p>Восстановление же психоэмоционального и физического здоровья происходит через обретение веры в себя, свои силы, в наличие собственного предназначения и в возможности радикального изменения своей жизни в лучшую сторону.</p>\r\n<p>Я хочу от всего сердца пожелать Вам принятия верного решения в выборе того или иного метода лечения проблемы, но помните одно: &laquo;Нельзя помочь двоим&nbsp;&mdash; мертвому и тому, кто не хочет&raquo;. Поэтому Вам стоит лишь понять, хотите ли Вы излечения, а остальное я беру уже в свои руки!<br /><br /><em>С Уважением,</em><br /><em>Павел Линев</em></p>', 'YES', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `default_sources`
--

DROP TABLE IF EXISTS `default_sources`;
CREATE TABLE IF NOT EXISTS `default_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `default_sources`
--

INSERT INTO `default_sources` (`id`, `name`) VALUES
(3, 'contacts_contacts'),
(1, 'contents_categories'),
(2, 'contents_posts');

-- --------------------------------------------------------

--
-- Структура таблицы `documents_posts`
--

DROP TABLE IF EXISTS `documents_posts`;
CREATE TABLE IF NOT EXISTS `documents_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  `meta_keywords` text,
  `meta_description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `documents_posts`
--

INSERT INTO `documents_posts` (`id`, `title`, `description`, `image`, `enabled`, `order`, `meta_keywords`, `meta_description`) VALUES
(7, 'Лицензия', 'Лицензия МОЗ Украины&nbsp; АВ № 565544, регистрация 02.09.2010 г.', '/uploads/lic.jpg', 'YES', NULL, NULL, NULL),
(8, 'Патент', 'Патент № 41030 от 27.04.2009 г.', '/uploads/patent.jpg', 'YES', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `frontpage_recovery_system`
--

DROP TABLE IF EXISTS `frontpage_recovery_system`;
CREATE TABLE IF NOT EXISTS `frontpage_recovery_system` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `image_hover` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `frontpage_recovery_system`
--

INSERT INTO `frontpage_recovery_system` (`id`, `title`, `description`, `image`, `image_hover`, `enabled`) VALUES
(7, 'Оригинальная методика', '<p>Программа реабилитации без угнетения психики &mdash; пациент самостоятельно отказывается от пагубного стиля жизни</p>', '/uploads/frontpage-recovery-system/scheme_orange.png', '/uploads/frontpage-recovery-system/scheme_orange_hover.png', 'YES'),
(8, 'Коллектив профессионалов', '<p>Персонал: научные, спортивные деятели с высшим образованием в области наркологии, психологии, психотерапии, педагогики</p>', '/uploads/frontpage-recovery-system/scheme_dblue.png', '/uploads/frontpage-recovery-system/scheme_dblue_hover.png', 'YES'),
(9, 'Клубная база в крыму', '<p>Отапливаемые финские домики, баня, купель, кухня, столовая, пасека, подсобное хозяйство</p>', '/uploads/frontpage-recovery-system/scheme_brown.png', '/uploads/frontpage-recovery-system/scheme_brown_hover.png', 'YES'),
(10, 'Жизнь среди природы', '<p>Ведение домашнего хозяйства, готовка пищи, купание в водопаде, занятие спортом, отдых</p>', '/uploads/frontpage-recovery-system/scheme_green.png', '/uploads/frontpage-recovery-system/scheme_green_hover.png', 'YES'),
(11, 'Поддержка и взаимовыручка', '<p>В кругу единомышленников больше шансов выздороветь. Персонал тактично подходит к проблемам, не угнетая психику, а возвращая жизнь и желание жить здорово</p>', '/uploads/frontpage-recovery-system/scheme_red.png', '/uploads/frontpage-recovery-system/scheme_red_hover.png', 'YES'),
(12, 'Ориентация на результат ', '<p>Психосоматическое восстановление&nbsp;&mdash; изоляция от привычной среды, формирование нового мировоззрения, исключая &laquo;промывание мозгов&raquo; и навязывания стереотипов</p>', '/uploads/frontpage-recovery-system/scheme_lblue.png', '/uploads/frontpage-recovery-system/scheme_lblue_hover.png', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `frontpage_slider`
--

DROP TABLE IF EXISTS `frontpage_slider`;
CREATE TABLE IF NOT EXISTS `frontpage_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `image_left` varchar(255) DEFAULT NULL,
  `image_right` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `frontpage_slider`
--

INSERT INTO `frontpage_slider` (`id`, `image`, `image_left`, `image_right`, `enabled`, `order`) VALUES
(7, '/uploads/front-page-slider/main-promo-collage--center.jpg', '/uploads/front-page-slider/main-promo-collage--left.jpg', '/uploads/front-page-slider/main-promo-collage--right.jpg', 'YES', NULL),
(8, '/uploads/front-page-slider/main-promo-collage--center--02.jpg', '/uploads/front-page-slider/main-promo-collage--left--02.jpg', '/uploads/front-page-slider/main-promo-collage--right--02.jpg', 'YES', NULL),
(9, '/uploads/front-page-slider/main-promo-collage--center--03.jpg', '/uploads/front-page-slider/main-promo-collage--left--03.jpg', '/uploads/front-page-slider/main-promo-collage--right--03.jpg', 'YES', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `frontpage_text`
--

DROP TABLE IF EXISTS `frontpage_text`;
CREATE TABLE IF NOT EXISTS `frontpage_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `button_text` varchar(255) DEFAULT NULL,
  `button_action` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `frontpage_text`
--

INSERT INTO `frontpage_text` (`id`, `title`, `description`, `button_text`, `button_action`, `enabled`) VALUES
(1, 'Мы нацелены на результат', '<p>Конечный результат участвующего в программе реабилитации и ресоциализации предусматривает возврат обществу и семье полноценного здорового индивидуума, который сумел изменить свое окружение и в дальнейшем придерживается тактики защиты от старой среды с помощью Клуба.</p>\r\n<p>Исходя из желания пациента, мы гарантируем формирование новой жизненной целеустановки на позитивное отношение к жизни, здоровый образ жизни, социальную реализацию и общий творческий процесс человека.&nbsp;</p>\r\n<p>После прохождения программы мы предлагаем своим уже бывшим пациентам участвовать в дальнейшей жизни Клуба: посещать семинары, тренинги, поддерживать общение с единомышленниками, приезжать в Клубную базу в Крыму для вдохновения здоровой жизнью. Возможно также содействие и поддержка при организации мероприятий Клуба в разных городах Украины, таких как Киев, Донецк, Днепропетровск, Симферополь.</p>', 'СДЕЛАЕМ ЭТО ВМЕСТЕ!', '/contents/methodology.html', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_pages`
--

DROP TABLE IF EXISTS `navigation_pages`;
CREATE TABLE IF NOT EXISTS `navigation_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `navigation_pages_id` int(11) DEFAULT NULL,
  `label` varchar(255) NOT NULL,
  `type` enum('URI','MVC') NOT NULL DEFAULT 'URI',
  `uri` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `module` varchar(255) DEFAULT NULL,
  `params` text,
  `route` varchar(255) DEFAULT NULL,
  `reset_params` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `encode_url` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  `meta_keywords` text,
  `meta_description` text,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`),
  KEY `navigation_pages_id` (`navigation_pages_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `navigation_pages`
--

INSERT INTO `navigation_pages` (`id`, `navigation_pages_id`, `label`, `type`, `uri`, `action`, `controller`, `module`, `params`, `route`, `reset_params`, `encode_url`, `order`, `enabled`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`, `meta_keywords`, `meta_description`) VALUES
(2, NULL, 'Главное меню', 'URI', '', '', '', '', '', '', 'YES', 'NO', NULL, 'YES', NULL, NULL, NULL, 1352715212, NULL, 1353940725, NULL, NULL),
(3, 2, 'Главная', 'MVC', '', 'index', 'index', 'default', '', '', 'YES', 'NO', 1, 'YES', NULL, NULL, NULL, 1352715271, NULL, 1354880015, '', ''),
(4, 2, 'О клубе', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"about_club"}', 'contents-static', 'YES', 'NO', 2, 'YES', NULL, NULL, NULL, 1352715319, NULL, 1354874724, NULL, NULL),
(5, 2, 'Оздоровление и реабилитация', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"methodology"}', 'contents-static', 'YES', 'NO', 3, 'YES', NULL, NULL, NULL, 1352715581, NULL, 1354874731, NULL, NULL),
(6, 2, 'База клуба', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"club_base"}', NULL, 'YES', 'NO', 4, 'YES', NULL, NULL, NULL, 1352723440, NULL, 1352794438, NULL, NULL),
(7, 2, 'Контакты', 'MVC', NULL, 'index', 'index', 'contacts', NULL, 'contacts', 'YES', 'NO', 5, 'YES', NULL, NULL, NULL, 1352723500, NULL, 1353492449, NULL, NULL),
(8, 4, 'Слово Руководителя', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"according-to-head-of"}', 'contents-static', 'YES', 'NO', 1, 'YES', NULL, NULL, NULL, 1352818173, NULL, 1354874740, NULL, NULL),
(9, 4, 'История', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"history"}', 'contents-static', 'YES', 'NO', 2, 'YES', NULL, NULL, NULL, 1352818248, NULL, 1354874749, NULL, NULL),
(10, 4, 'Миссия и цели', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"mission-and-goals"}', NULL, 'YES', 'NO', 3, 'YES', NULL, NULL, NULL, 1352818297, NULL, NULL, NULL, NULL),
(11, 4, 'Документы', 'MVC', '', 'index', 'index', 'documents', '', 'documents', 'YES', 'NO', 4, 'YES', NULL, NULL, NULL, 1352818366, NULL, 1354008031, NULL, NULL),
(12, 4, 'Персонал', 'MVC', '', 'index', 'index', 'staff', '', 'staff', 'YES', 'NO', 5, 'YES', NULL, NULL, NULL, 1352818409, NULL, 1354002788, NULL, NULL),
(13, 4, 'Рекомендации', 'MVC', NULL, 'index', 'index', 'recommendations', NULL, 'recommendations', 'YES', 'NO', 6, 'YES', NULL, NULL, NULL, 1352818440, NULL, 1352991392, NULL, NULL),
(14, 6, 'Фотогалерея', 'MVC', NULL, 'index', 'index', 'photogallery', NULL, 'photogallery', 'YES', 'NO', 7, 'YES', NULL, NULL, NULL, 1353008102, NULL, 1353490087, NULL, NULL),
(15, 5, 'Сущность программы', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"program"}', 'contents-static', 'YES', 'NO', NULL, 'YES', NULL, NULL, NULL, 1353943979, NULL, 1354874759, NULL, NULL),
(16, 5, 'Результаты прохождения программы', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"findings"}', 'contents-static', 'YES', 'NO', NULL, 'YES', NULL, NULL, NULL, 1353944107, NULL, 1354874768, NULL, NULL),
(17, 5, 'Расписание дня в лагере', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"schedule"}', 'contents-static', 'YES', 'NO', NULL, 'YES', NULL, NULL, NULL, 1353944305, NULL, 1354874776, NULL, NULL);

--
-- Триггеры `navigation_pages`
--
DROP TRIGGER IF EXISTS `BEFORE_INSERT_navigation_pages`;
DELIMITER //
CREATE TRIGGER `BEFORE_INSERT_navigation_pages` BEFORE INSERT ON `navigation_pages`
 FOR EACH ROW BEGIN
	SET `NEW`.`created_ts` = UNIX_TIMESTAMP();
	IF `NEW`.`checked_out_by` IS NOT NULL THEN
	    SET `NEW`.`checked_out_ts` = UNIX_TIMESTAMP();
	ELSE
	    SET `NEW`.`checked_out_ts` = NULL;
	END IF;
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `BEFORE_UPDATE_navigation_pages`;
DELIMITER //
CREATE TRIGGER `BEFORE_UPDATE_navigation_pages` BEFORE UPDATE ON `navigation_pages`
 FOR EACH ROW BEGIN
	SET `NEW`.`modified_ts` = UNIX_TIMESTAMP();
	IF `NEW`.`checked_out_by` IS NOT NULL THEN
	    SET `NEW`.`checked_out_ts` = UNIX_TIMESTAMP();
	ELSE
	    SET `NEW`.`checked_out_ts` = NULL;
	END IF;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_roles`
--

DROP TABLE IF EXISTS `navigation_roles`;
CREATE TABLE IF NOT EXISTS `navigation_roles` (
  `navigation_id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  `type` enum('ALLOW','DENY') NOT NULL DEFAULT 'ALLOW',
  KEY `navigation_id` (`navigation_id`),
  KEY `roles_id` (`roles_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `navigation_roles`
--

INSERT INTO `navigation_roles` (`navigation_id`, `roles_id`, `type`) VALUES
(2, 1, 'ALLOW');

-- --------------------------------------------------------

--
-- Структура таблицы `photogallery_albums`
--

DROP TABLE IF EXISTS `photogallery_albums`;
CREATE TABLE IF NOT EXISTS `photogallery_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photogallery_albums_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `description` text,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  `meta_keywords` text,
  `meta_description` text,
  PRIMARY KEY (`id`),
  KEY `photogallery_albums_id` (`photogallery_albums_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `photogallery_albums`
--

INSERT INTO `photogallery_albums` (`id`, `photogallery_albums_id`, `title`, `alias`, `description`, `enabled`, `order`, `meta_keywords`, `meta_description`) VALUES
(7, NULL, 'База', 'base', '', 'YES', NULL, '', ''),
(8, NULL, 'Жизнь в Клубе', 'life-roy', '', 'YES', NULL, '', ''),
(9, NULL, 'Пещера и окрестности', 'peschera', '', 'YES', NULL, '', ''),
(10, NULL, 'Персонал', 'ludi', '', 'YES', NULL, '', ''),
(11, NULL, 'Внутри', 'dom', '', 'YES', NULL, '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `photogallery_images`
--

DROP TABLE IF EXISTS `photogallery_images`;
CREATE TABLE IF NOT EXISTS `photogallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photogallery_albums_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  `cover` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `created_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `photogallery_albums_id` (`photogallery_albums_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=85 ;

--
-- Дамп данных таблицы `photogallery_images`
--

INSERT INTO `photogallery_images` (`id`, `photogallery_albums_id`, `title`, `description`, `image`, `enabled`, `order`, `cover`, `created_ts`) VALUES
(12, 9, '1', '', '/uploads/img_6655.jpg', 'YES', NULL, 'NO', NULL),
(13, 9, '2', '', '/uploads/img_6660.jpg', 'YES', NULL, 'NO', NULL),
(14, 9, '3', '', '/uploads/img_6662.jpg', 'YES', NULL, 'NO', NULL),
(15, 9, '4', '', '/uploads/img_6684.jpg', 'YES', NULL, 'NO', NULL),
(16, 9, '5', '', '/uploads/img_6696.jpg', 'YES', NULL, 'NO', NULL),
(17, 9, '6', '', '/uploads/img_6701.jpg', 'YES', NULL, 'NO', NULL),
(18, 9, '7', '', '/uploads/img_6705.jpg', 'YES', NULL, 'NO', NULL),
(19, 9, '8', '', '/uploads/img_6712.jpg', 'YES', NULL, 'NO', NULL),
(20, 9, '9', '', '/uploads/img_6713.jpg', 'YES', NULL, 'NO', NULL),
(21, 9, '10', '', '/uploads/img_6716.jpg', 'YES', NULL, 'NO', NULL),
(22, 9, '11', '', '/uploads/img_6722.jpg', 'YES', NULL, 'NO', NULL),
(23, 9, '12', '', '/uploads/img_6724.jpg', 'YES', NULL, 'NO', NULL),
(24, 8, '13', '', '/uploads/img_6726.jpg', 'YES', NULL, 'NO', NULL),
(26, 7, '15', '', '/uploads/img_6728.jpg', 'YES', NULL, 'NO', NULL),
(27, 7, '16', '', '/uploads/img_6729.jpg', 'YES', NULL, 'NO', NULL),
(28, 7, '17', '', '/uploads/img_6741.jpg', 'YES', NULL, 'NO', NULL),
(29, 7, '18', '', '/uploads/img_6743.jpg', 'YES', NULL, 'NO', NULL),
(30, 7, '19', '', '/uploads/img_6744.jpg', 'YES', NULL, 'NO', NULL),
(31, 7, '20', '', '/uploads/img_6752.jpg', 'YES', NULL, 'NO', NULL),
(32, 7, '21', '', '/uploads/img_6754.jpg', 'YES', NULL, 'NO', NULL),
(33, 7, '22', '', '/uploads/img_6757.jpg', 'YES', NULL, 'NO', NULL),
(34, 7, '23', '', '/uploads/img_6759.jpg', 'YES', NULL, 'NO', NULL),
(35, 7, '24', '', '/uploads/img_6780.jpg', 'YES', NULL, 'NO', NULL),
(36, 7, '25', '', '/uploads/img_6793.jpg', 'YES', NULL, 'NO', NULL),
(37, 7, '26', '', '/uploads/img_6822.jpg', 'YES', NULL, 'NO', NULL),
(38, 9, '27', '', '/uploads/img_6832.jpg', 'YES', NULL, 'NO', NULL),
(39, 9, '28', '', '/uploads/img_6835.jpg', 'YES', NULL, 'NO', NULL),
(40, 9, '29', '', '/uploads/img_6839.jpg', 'YES', NULL, 'NO', NULL),
(41, 9, '30', '', '/uploads/img_6838.jpg', 'YES', NULL, 'NO', NULL),
(42, 9, '31', '', '/uploads/img_6857.jpg', 'YES', NULL, 'NO', NULL),
(43, 9, '32', '', '/uploads/img_6880.jpg', 'YES', NULL, 'NO', NULL),
(44, 9, '33', '', '/uploads/img_6905.jpg', 'YES', NULL, 'NO', NULL),
(49, 7, '1', '', '/uploads/BM0R6714.jpg', 'YES', NULL, 'NO', NULL),
(50, 7, '2', '', '/uploads/BM0R6760.jpg', 'YES', NULL, 'NO', NULL),
(51, 7, '3', '', '/uploads/BM0R6764.jpg', 'YES', NULL, 'NO', NULL),
(52, 7, '4', '', '/uploads/BM0R6768.jpg', 'YES', NULL, 'NO', NULL),
(53, 7, '5', '', '/uploads/BM0R6769.jpg', 'YES', NULL, 'NO', NULL),
(54, 7, '6', '', '/uploads/BM0R6774.jpg', 'YES', NULL, 'NO', NULL),
(55, 7, '7', '', '/uploads/BM0R6781.jpg', 'YES', NULL, 'NO', NULL),
(56, 7, '8', '', '/uploads/BM0R6788.jpg', 'YES', NULL, 'NO', NULL),
(57, 7, '9', '', '/uploads/BM0R6790.jpg', 'YES', NULL, 'NO', NULL),
(58, 7, '10', '', '/uploads/BM0R6792.jpg', 'YES', NULL, 'NO', NULL),
(59, 7, '11', '', '/uploads/BM0R6800.jpg', 'YES', NULL, 'NO', NULL),
(61, 7, '13', '', '/uploads/BM0R6804.jpg', 'YES', NULL, 'NO', NULL),
(62, 7, '14', '', '/uploads/BM0R6811.jpg', 'YES', NULL, 'NO', NULL),
(63, 10, '15', '', '/uploads/BM0R6872.jpg', 'YES', NULL, 'NO', NULL),
(64, 10, '16', '', '/uploads/BM0R6901.jpg', 'YES', NULL, 'NO', NULL),
(65, 10, '17', '', '/uploads/BM0R6904.jpg', 'YES', NULL, 'NO', NULL),
(66, 8, '18', '', '/uploads/BM0R6708.jpg', 'YES', NULL, 'NO', NULL),
(67, 8, '19', '', '/uploads/BM0R6711.jpg', 'YES', NULL, 'NO', NULL),
(68, 8, '20', '', '/uploads/BM0R7106_2.jpg', 'YES', NULL, 'NO', NULL),
(69, 11, '21', '', '/uploads/BM0R6908.jpg', 'YES', NULL, 'NO', NULL),
(70, 11, '22', '', '/uploads/BM0R6911.jpg', 'YES', NULL, 'NO', NULL),
(71, 11, '23', '', '/uploads/BM0R6912.jpg', 'YES', NULL, 'NO', NULL),
(72, 11, '24', '', '/uploads/BM0R6942.jpg', 'YES', NULL, 'NO', NULL),
(73, 11, '25', '', '/uploads/BM0R6958.jpg', 'YES', NULL, 'NO', NULL),
(74, 8, '26', '', '/uploads/BM0R7117.jpg', 'YES', NULL, 'NO', NULL),
(75, 8, '27', '', '/uploads/BM0R7098.jpg', 'YES', NULL, 'NO', NULL),
(76, 8, '28', '', '/uploads/BM0R7119.jpg', 'YES', NULL, 'NO', NULL),
(77, 8, '28', '', '/uploads/BM0R7122.jpg', 'YES', NULL, 'NO', NULL),
(78, 8, '29', '', '/uploads/BM0R7124.jpg', 'YES', NULL, 'NO', NULL),
(79, 8, '30', '', '/uploads/BM0R7135.jpg', 'YES', NULL, 'NO', NULL),
(80, 8, '31', '', '/uploads/BM0R7137.jpg', 'YES', NULL, 'NO', NULL),
(81, 8, '32', '', '/uploads/BM0R7138.jpg', 'YES', NULL, 'NO', NULL),
(82, 8, '33', '', '/uploads/1111.jpg', 'YES', NULL, 'NO', NULL),
(83, 11, '26', '', '/uploads/1233.jpg', 'YES', NULL, 'NO', NULL),
(84, 11, '27', '', '/uploads/1234.jpg', 'YES', NULL, 'NO', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `recommendations_posts`
--

DROP TABLE IF EXISTS `recommendations_posts`;
CREATE TABLE IF NOT EXISTS `recommendations_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  `meta_keywords` text,
  `meta_description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `recommendations_posts`
--

INSERT INTO `recommendations_posts` (`id`, `title`, `description`, `image`, `enabled`, `order`, `meta_keywords`, `meta_description`) VALUES
(7, 'Республиканский наркологический диспансер АР Крым', 'Спортивно-оздоровительный клуб &laquo;РОЙ&raquo; &mdash; зрелое реабилитационное учреждение, предоставляющее наркозависимым помощь на этапах реадаптаци, реабилитации и дальнейшей ресоциализации.\r\n<p>В клубе разработана оригинальная 4-х шаговая методика реабилитаци, основанная на физиотерапевтических природных процедурах, психологическом воздействии средой и коллективной трудотерапией.</p>\r\n<p>В реабилитационном процессе используются бывшие пациенты&nbsp;&mdash; инструктора. Пациенты реабилитационной программы живут ощущением единой команды, проживают в общих палатках с инструкторами. Медицинские препараты в программе не применяются, за исключением сборов трав и продуктов пчеловодства.</p>\r\n<p>Клуб &laquo;РОЙ&raquo; обеспечил реабилитационную работу европейского уровня, что отличает его от многих реабилитационных наркологических учреждений. Для Украины реабилитационная программа клуба &laquo;РОЙ&raquo;&nbsp;&mdash; один из ростков наркологии будущего.</p>', '/uploads/belickiy.gif', 'YES', NULL, NULL, NULL),
(8, 'Кафедра психиатрии, наркологии и психотерапии Крымского медицинского университета им. С.И.Георгиевского', '<p>Предлагаемая спортивно-оздоровительным клубом &laquo;РОЙ&raquo; программа работы с лицами, зависимыми от психоактивных веществ, а также зависимых от других объектов (компьютера, азартных игр, секса и т.д.) включает в себя комплекс реабилитации и ресоциализации, которые хорошо согласуются с требованиями современной психотерапевтической, клинической практики. Программа является эффективной при снятии основных наркологических синдромов, реабилитации и последующей социальной адаптации.</p>\r\n<p>В частности, реабилитационная программа включает в себя широкий арсенал приемов биологической терапии, физиотерапии, индивидуальной и групповой психотерапии. Фармакотерапевтическое вмешательство не применяется. Лишь в тяжелых случаях при необходимости проводится детоксикационная (дезинтоксикационная), заместительная, а также ургентная (неотложная) терапия.</p>\r\n<p>Отличительной чертой программы клуба &laquo;РОЙ&raquo;, созданной ее руководителем Линевым Павлом Владимировичем, является полное погружение в необычную для большинства зависимых среду. В ней &laquo;природный образ жизни&raquo; и восточные практики оздоровления и физического развития (адаптированные для нашего менталитета) создают благоприятный фон для проведения процедур групповой психотерапии и физиотерапевтического воздействия.</p>\r\n<p>Данную программу модно рекомендовать для реабилитации пациентов с легкой и средней степенью зависимости, а в некоторых случаях&nbsp;&mdash; и при тяжелых формах зависимости, в том числе прошедшим курс стационарного лечения в специализированных наркологических учреждениях. Программа также рекомендуется для оздоровления, реабилитации лиц с различными невротическими расстройствами и психологическими проблемами в подростковом возрасте.</p>', '/uploads/klinkov.gif', 'YES', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roles_id` int(11) DEFAULT NULL,
  `alias` varchar(255) NOT NULL,
  `system` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `roles_id` (`roles_id`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `created_by` (`created_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `roles_id`, `alias`, `system`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`) VALUES
(1, NULL, 'Super administrator', 'NO', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `staff_staff`
--

DROP TABLE IF EXISTS `staff_staff`;
CREATE TABLE IF NOT EXISTS `staff_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `staff_staff`
--

INSERT INTO `staff_staff` (`id`, `name`, `phone`, `email`, `skype`, `description`, `image`, `enabled`, `order`) VALUES
(7, 'Линев Павел Владимирович', '+38 050 545 33 69', 'pavel@roi-crimea.org', '', '<p>Руководитель клуба.<br />Психолог, педагог, спортивный тренер.<br />Образование:<br />1. Киевский Институт физкультуры;<br />2. Крымский педагогический институт, факультет Практической психологии.<br />Имеет 1 дан по киокушин, 2 дан по рукопашному бою, КМС по самбо.</p>', '/uploads/BM0R6902_-__-__2.jpg', 'YES', NULL),
(8, 'Нигирин Евгений Викторович', '', '', '', 'Врач высшей категории, психиатр-нарколог.', '', 'YES', NULL),
(9, 'Клинков Валерий Николаевич', '', 'klinkov@roi-crimea.org', '', 'Консультант.<br />Доцент кафедры психиатрии, наркологии и психотерапии Крымского медицинского университета.', '', 'YES', NULL),
(10, 'Соколов Олег Олегович', '+38 050 363 22 33', 'sokol_1@inbox.ru', '', 'Воспитатель.<br />Инструктор, тренер по реабилитационно-тренировочной методике Голтиса, председатель Днепропетровской федерации карате.', '/uploads/BM0R6902_-_.jpg', 'YES', NULL),
(11, 'Капустин Иван Петрович', '', '', '', 'Воспитатель.<br />Инструктор, тренер по рукопашному бою.', '', 'YES', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
CREATE TABLE IF NOT EXISTS `users_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `roles_id` (`roles_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users_roles`
--

INSERT INTO `users_roles` (`id`, `users_id`, `roles_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users_users`
--

DROP TABLE IF EXISTS `users_users`;
CREATE TABLE IF NOT EXISTS `users_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `system` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `register_ts` int(11) DEFAULT NULL,
  `lastvizit_ts` int(11) DEFAULT NULL,
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users_users`
--

INSERT INTO `users_users` (`id`, `email`, `password`, `enabled`, `system`, `register_ts`, `lastvizit_ts`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`) VALUES
(1, 'admin@admin.com', 'e10adc3949ba59abbe56e057f20f883e', 'YES', 'NO', 1350741357, 0, NULL, 0, NULL, 0, NULL, 0),
(2, 'marina@sunny.net.ua', 'ce5225d01c39d2567bc229501d9e610d', 'YES', 'NO', 1353684342, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `contacts_contacts`
--
ALTER TABLE `contacts_contacts`
  ADD CONSTRAINT `contacts_contacts_ibfk_1` FOREIGN KEY (`contacts_groups_id`) REFERENCES `contacts_groups` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Ограничения внешнего ключа таблицы `navigation_pages`
--
ALTER TABLE `navigation_pages`
  ADD CONSTRAINT `navigation_pages_ibfk_1` FOREIGN KEY (`checked_out_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `navigation_pages_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `navigation_pages_ibfk_3` FOREIGN KEY (`modified_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `navigation_pages_ibfk_4` FOREIGN KEY (`navigation_pages_id`) REFERENCES `navigation_pages` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `navigation_roles`
--
ALTER TABLE `navigation_roles`
  ADD CONSTRAINT `navigation_roles_ibfk_2` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `navigation_roles_ibfk_3` FOREIGN KEY (`navigation_id`) REFERENCES `navigation_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `photogallery_albums`
--
ALTER TABLE `photogallery_albums`
  ADD CONSTRAINT `photogallery_albums_ibfk_1` FOREIGN KEY (`photogallery_albums_id`) REFERENCES `photogallery_albums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `photogallery_images`
--
ALTER TABLE `photogallery_images`
  ADD CONSTRAINT `photogallery_images_ibfk_1` FOREIGN KEY (`photogallery_albums_id`) REFERENCES `photogallery_albums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `roles`
--
ALTER TABLE `roles`
  ADD CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `roles_ibfk_2` FOREIGN KEY (`checked_out_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `roles_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `roles_ibfk_4` FOREIGN KEY (`modified_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users_roles`
--
ALTER TABLE `users_roles`
  ADD CONSTRAINT `users_roles_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_roles_ibfk_2` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users_users`
--
ALTER TABLE `users_users`
  ADD CONSTRAINT `users_users_ibfk_4` FOREIGN KEY (`checked_out_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_users_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_users_ibfk_6` FOREIGN KEY (`modified_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
